package com.apaka;

import java.util.*;

public class Json{
    public static String encodeJson(HashMap<String,String> arr){
		String return_str="{";
        try{
            int i=0;
                for(Map.Entry m:arr.entrySet()){
                    i++;
                    String key=m.getKey().toString();
                    String val=m.getValue().toString();
                    String comma=",";
                    if(i==arr.size()){
                        comma="";
                    }
                    return_str=return_str+"\""+key+"\":\""+val+"\""+comma;
                }
        }catch(Exception ex){
            System.out.println(ex.toString());
        }

        return_str=return_str+"}";

		return return_str;
	}

	public static HashMap<String ,String> decodeJson(String str){
		HashMap<String,String> string=new HashMap<String,String>();
        try{
            String[] arrays=str.substring(1,str.length()-1).split(",");
            if(arrays.length>0){
                for(int i=0;i<arrays.length;i++){
                    if(arrays[i].indexOf(":")>0){
                        String[] a=arrays[i].split(":");
                        string.put(a[0],a[1]);
                    }
                }
            }
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
		return string;
	}
}