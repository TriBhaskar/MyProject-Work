package com.apaka;

import java.lang.*;
import java.util.*;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class MainInclude extends HttpServlet{
    public void doHead(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
        
    }
}
