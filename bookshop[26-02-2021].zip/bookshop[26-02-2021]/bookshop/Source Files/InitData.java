package com.apaka;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InitData{
	private Connection con;

	public InitData(){
		initCon();
	}
	
	public void initCon(){

		try{
			String dbDriver="com.mysql.jdbc.Driver",dbURL="jdbc:mysql://localhost/",dbName="bookera",dbUName="root",dbPassword="";
			Class.forName(dbDriver);
			Connection con=DriverManager.getConnection(dbURL+dbName,dbUName,dbPassword);
			this.con=con;
		}
		catch(Exception ex){
		}
	}

	public Connection getConnection(){
		return this.con;
	}


	public String base64Encode3(String str){
		return this.base64Encode(this.base64Encode(this.base64Encode(str)));
	}

	public String base64Encode(String str){
		String code="";
		if(str!=null && str.length()>0){
			code=Base64.getEncoder().encodeToString(str.getBytes());
		}
		return code;
	}

	public String base64Decode(String str){
		String code="";
		if(str!=null && str.length()>0){
			code=(new String(Base64.getDecoder().decode(str)));
		}
		return code;
	}
	
	public String base64Decode3(String str){
		return this.base64Decode(this.base64Decode(this.base64Decode(str)));
	}

	public String ucWords(String str){
		String temp = "";
		try{
			String[] strs = str.split(" ");
			if(strs.length>0){
				for(String a : strs)
					temp = temp +" "+ this.ucWord(a);
			}
			else{
				temp = str;
			}
		}catch (Exception e) {}
		return temp.trim();
	}

	public String ucWord(String str){
		String temp = str;
		try{
			if(str.length()>0)
				temp = (""+temp.charAt(0)+"").toUpperCase()+""+temp.substring(1,temp.length());
		}catch (Exception e) {}
		return temp;
	}
	
}
