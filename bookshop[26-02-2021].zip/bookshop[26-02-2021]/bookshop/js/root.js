
	if(JSON.stringify(document.querySelectorAll("*[goto]"))!=null){
		let list = document.querySelectorAll("*[goto]");
			list.forEach(me=>{
				me.onclick=()=>{
					window.location.href = me.getAttribute("goto");
				}
			})
	}

/**/
	let inps = document.querySelectorAll(".inputfield");
	inps.forEach(ele=>{
		let me  = ele.children[0].children[1];
		me.onfocus=()=>{
			me.parentNode.classList.add("focus");
		}
		me.onblur=()=>{
			me.parentNode.classList.remove("focus");
			if(me.value.length>0){
				me.parentNode.classList.add("filled");
			}
			else{
				me.parentNode.classList.remove("filled");
			}
		}
	});

	let eyes = document.querySelectorAll(".eyes");
	eyes.forEach(m=>{
		m.onclick=()=>{
			let chk = m.previousElementSibling;
			if(chk instanceof HTMLInputElement){
				let ty = chk.getAttribute("type");
					if(ty=="password"){
						chk.type="text";
						m.classList.remove("fa-eye");
						m.classList.add("fa-eye-slash");
					}
					else if(ty=="text"){
						chk.type="password";
						m.classList.remove("fa-eye-slash");
						m.classList.add("fa-eye");
					}
			}
		}

	});

/**/

	function fillForm(form) {
		let formData = {};
			for(const a of form){
				let str = a.value;
				if (a.type=="checkbox")
					str = ((a.checked===true)?a.value='true':a.value='false');
				formData[a.name]=str;
			}
		return formData;
	}

/* make class for dynamic dialog box creating */
	class Dialog{
		icons = {"suc":"fa-check","error":"fa-bug","alert":"fa-exclamation-triangle","info":"fa-exclamation-circle","norm":"fa-gift"};
		text = "Say! Hello.";
		loading = null;
		rootNode = null;
		constructor(){
			if(this.rootNode==null){
				this.makeRoot();
				this.makeLoadingBox();
			}
		}
		makeLoadingBox(){
			let div1 = document.createElement("div");
				div1.setAttribute("class","loadingCont");
				let div2 = document.createElement("div");
					div2.setAttribute("class","loading_box");
					let div3 = document.createElement("div");
						div3.setAttribute("class","cont_box");
						let div4 = document.createElement("div");
							div4.setAttribute("class","loding");
								let span1 = document.createElement("span");
								span1.setAttribute("class","top");
								let span2 = document.createElement("span");
								span2.setAttribute("class","left");
								let span3 = document.createElement("span");
								span3.setAttribute("class","right");
								let span4 = document.createElement("span");
								span4.setAttribute("class","bottom");
								div4.appendChild(span1);
								div4.appendChild(span2);
								div4.appendChild(span3);
								div4.appendChild(span4);
					div3.appendChild(div4);
				div2.appendChild(div3);
			div1.appendChild(div2);			
			this.loading=div1;
		}

		addLoading(){
			if(this.loading!=null){
				document.body.appendChild(this.loading);
			}
		}		
		removeLoading(){
			if(JSON.stringify(document.querySelector(".loadingCont"))!=null){
				document.querySelector(".loadingCont").remove();
			}
		}

		makeDialog(type,msg){
			let box = document.createElement("div");
				box.setAttribute("class","_box");
				let art = document.createElement("div");
					art.setAttribute("class","_articale");
					let lbl = document.createElement("label");
						lbl.setAttribute("class","diaTimes");
						let lblI = document.createElement("i");
							lblI.setAttribute("class","fa fa-times");

						lbl.appendChild(lblI);
						lbl.onclick=()=>{this.closeRoot()};

					let gridBox = document.createElement("div");
						gridBox.setAttribute("class","gridBox "+type);
						
						let div1 = document.createElement("div");
							let icon = document.createElement("i");
								icon.setAttribute("class","fa "+this.icons[type]);

							div1.appendChild(icon);
						let div2 = document.createElement("div");
							let p = document.createElement("p");
								p.innerHTML=msg;

							div2.appendChild(p);

					gridBox.appendChild(div1);
					gridBox.appendChild(div2);

				art.appendChild(lbl);
				art.appendChild(gridBox);

			box.appendChild(art);

			return box;
		}

		makeRoot(){
			if(JSON.stringify(document.querySelector(".apaka-popupCont"))!=null){
				let div = document.createElement("div");
					div.setAttribute("class","apaka-popupCont");
					this.rootNode = div;
					document.body.prepend(div);
			}
			else{
				this.rootNode = document.querySelector(".apaka-popupCont");
			}
		}

		closeRoot(){
			if(this.rootNode!=null){
				let stl = window.getComputedStyle(this.rootNode,"display");
				let ch = stl.display;
				if(ch=="flex"){
					this.rootNode.setAttribute("close","");
					setTimeout(()=>{
						this.rootNode.classList.remove("open");
						this.rootNode.removeAttribute("close");
						this.removeRootNodes();
					},300);
				}
			}
		}

		errorDialog(msg){
			if(this.rootNode!=null){
				this.removeRootNodes();
				this.rootNode.appendChild(this.makeDialog("error",msg));
				this.rootNode.classList.add("open");
			}
			else{
				this.makeRoot();
				this.errorDialog(msg);
			}
		}

		sucDialog(msg){
			if(this.rootNode!=null){
				this.removeRootNodes();
				this.rootNode.appendChild(this.makeDialog("suc",msg));
				this.rootNode.classList.add("open");
			}
			else{
				this.makeRoot();
				this.sucDialog(msg);
			}
		}

		infoDialog(msg){
			if(this.rootNode!=null){
				this.removeRootNodes();
				this.rootNode.appendChild(this.makeDialog("info",msg));
				this.rootNode.classList.add("open");
			}
			else{
				this.makeRoot();
				this.infoDialog(msg);
			}
		}

		alertDialog(msg){
			if(this.rootNode!=null){
				this.removeRootNodes();
				this.rootNode.appendChild(this.makeDialog("alert",msg));
				this.rootNode.classList.add("open");
			}
			else{
				this.makeRoot();
				this.alertDialog(msg);
			}
		}

		normDialog(msg){
			if(this.rootNode!=null){
				this.removeRootNodes();
				this.rootNode.appendChild(this.makeDialog("norm",msg));
				this.rootNode.classList.add("open");
			}
			else{
				this.makeRoot();
				this.normDialog(msg);
			}
		}

		removeRootNodes(){
			let nodes = this.rootNode.children;
			//if(nodes>=0){
				for(let i=0;i<=nodes.length-1;i++){
					let n = nodes[i];
					this.rootNode.removeChild(n);
				}
			//}
		}

	}

	let dia = new Dialog();
	// dia.sucDialog("");
	// dia.normDialog("");
	
	function clickMe(){
		dia.errorDialog("");
	}

	function showBE_Errors(arg1,arg2){
		dia.errorDialog("<b>JS:ERROR</b><br/>"+arg1.message+"<br/><br/><b>BE:ERROR</b><br/>"+arg2);
	}
/* make class for dynamic dialog box creating */

