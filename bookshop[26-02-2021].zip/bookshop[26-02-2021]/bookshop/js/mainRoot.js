let trap = document.querySelector(".tracker[trap]");
    if(trap!=null){
        trap.onclick=(e)=>{
            let ch = document.querySelector(".mainCont");
            if(ch.hasAttribute("close")){
                ch.removeAttribute("close");
                this.children[0].classList.remove("fa-chevron-left");
                this.children[0].classList.add("fa-chevron-right");
            }
            else{
                ch.setAttribute("close","");
                this.children[0].classList.remove("fa-chevron-right");
                this.children[0].classList.add("fa-chevron-left");

            }
        }
    }